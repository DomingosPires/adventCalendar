$(document).ready(function() {

    if ($(".calendario_advento").length > 0) {
        console.log("== CALENDARIO ADVENTO ==")
        $("body").addClass("transform_unset");

        var date = new Date();
        var date_day = date.getDate();

        var data_targetsize = "0.6";

        if ($(window).width() > 768) {
            var data_targetsize = "0.6";
        } else {
            var data_targetsize = "0.9";
        }

        $(".grid__item").each(function() {

            //$(this).addClass("zoomTarget").attr("data-scalemode","both").attr("data-targetsize",data_targetsize).attr("easing" ,"ease-in-out");

            /*=========== IF YOU WANT ALL THE DAYS OPEN UNCOMMENT ABOVE CODE AND COMMENT THE "IF" BELLOW ============*/

            if ($(this).attr("data-id") == date_day) {
                $(this).addClass("zoomTarget").attr("data-scalemode", "both").attr("data-targetsize", data_targetsize).attr("easing", "ease-in-out");
            } else if ($(this).attr("data-id") < date_day) {
                $(this).addClass("day_passed")
                var img_gift = $(this).find(".grid__item-door").css('background-image')
                img_gift = img_gift.replace("url(", "").replace(")", "")
                $(this).find(".grid__item-door").css("background", "linear-gradient(0deg, rgb(0 0 0 / 65%), rgb(0 0 0 / 65%)),url(" + img_gift + ")");
            } else if ($(this).attr("data-id") > date_day) {
                $(this).addClass("not_yet")
            }
        });

        $(".grid__item.zoomTarget").zoomTarget();


        $(".grid__item.zoomTarget").click(function(e) {

            var bg_image = $(this).find(".grid__item-door").css('background-image')
            bg_image = bg_image.replace("url(", "").replace(")", "")

            if ($(this).find(".advento").length > 0) {
                $(this).find(".advento").remove();
                $(this).find(".btn-close-gift").remove();
                $(this).find(".grid__item-door").addClass("untransform");
                $(this).find(".grid__item-door").removeClass("z-index-1");
            } else {
                $(this).find(".grid__item-door").removeClass("untransform");
                $(this).find(".grid__item-door").addClass("z-index-1");
            }

            $("body").removeClass("transform_unset");

            var days_data = new Object();

            if (window.location.href.includes("mrblue.pt/en/pages/calendario-do-advento-mr-blue-2022")) {
                console.log("EN")
                    /* == DATA ENGLISH == */
                days_data = [
                    { day: 1, text: "-20% site-wide", subtext: "* Discount valid only for New Collection items and cannot be combined with other promotions.", promo_code: "Código: SUPER20" },
                    { day: 2, text: "-30% on Accessories", subtext: "* Discount valid only for New Collection items and cannot be combined with other promotions.", promo_code: "Código: ACESSORIOS30" },
                    { day: 3, text: "-15% on Formal Shoes", subtext: "* Discount not combinable with other promotions.", promo_code: "Código: SAPATOS15" },
                    { day: 4, text: "Free Shipping", subtext: "* Valid only for mainland Portugal.", promo_code: "Código: FREESHIPPING1" },
                    { day: 5, text: "3X2 in Boxers", subtext: "* Discount directly in the cart. Valid only for New Collection items and not combinable with other promotions.", promo_code: "" },
                    { day: 6, text: "25% off Pajamas", subtext: "* Discount valid only for New Collection items and cannot be combined with other promotions.", promo_code: "Código: PIJAMAS25" },
                    { day: 7, text: "Additional 10% when buying 3 or more items", subtext: "* Discount valid only for New Collection items and cannot be combined with other promotions.", promo_code: "Código: MAIS10" },
                    { day: 8, text: "20% + 5% EXTRA on Coats, <br> Overcoats and Blazers", subtext: "* Discount valid only for New Collection items <br> and cannot be combined with other promotions.", promo_code: "Código: EXTRA5" },
                    { day: 9, text: "Free Shipping", subtext: "* Valid only for mainland Portugal.", promo_code: "Código: FREESHIPPING2" },
                    { day: 10, text: "50% + 10% Additional on Selected Items", subtext: "* Discount not combinable with other promotions.", promo_code: "Código: 50MAIS10" },
                    { day: 11, text: "Scarves <br> -40% on the 2nd item", subtext: "* Discount directly in the cart. <br>Valid only for New Collection items and priced at €35.99. <br>Discount not combinable with other promotions.", promo_code: "" },
                    { day: 12, text: "-15% in Pullovers", subtext: "* Discount valid only for New Collection items and cannot be combined with other promotions.", promo_code: "Código: PULLOVERS15" },
                    { day: 13, text: "Receive an exclusive Mr. Blue <br>with your order.", subtext: "*Valid for all online orders before <br> December 13, 2022.", promo_code: "" },
                    { day: 14, text: "-25% on Shirts", subtext: "* Discount valid only for New Collection items and cannot be combined with other promotions.", promo_code: "Código: CAMISAS25" },
                    { day: 15, text: "Scarves <br> 2 for 29.99€", subtext: "* Discount directly in the cart. Valid only for New Collection items<br> and priced at €19.99. Discount not combinable with other promotions.", promo_code: "" },
                    { day: 16, text: "5€ on purchases over 65€ <br> 10€ on purchases over 75€ <br> 25€ on purchases over 95€ ", subtext: "* Discount directly in the cart. Valid only for New Collection items<br> and cannot be combined with other promotions.", promo_code: "" },
                    { day: 17, text: "Free Shipping", subtext: "* Valid only for mainland Portugal.", promo_code: "Código: FREESHIPPING3" },
                    { day: 18, text: "2nd T-shirt €9.99", subtext: "* Discount directly in the cart. Valid only for New Collection items and cannot be combined with other promotions.", promo_code: "" },
                    { day: 19, text: "-25% on Pants", subtext: "* Discount valid only for New Collection items and cannot be combined with other promotions.", promo_code: "Código: CALCAS25" },
                    { day: 20, text: "5 Socks for €19.99", subtext: "* Discount directly in the cart. Only valid for €12.99 items and cannot be combined with other promotions.", promo_code: "" },
                    { day: 21, text: "-20% on Polos & Rugbies", subtext: "* Discount valid only for New Collection items and cannot be combined with other promotions.", promo_code: "Código: POLOSERUGBIES20" },
                    { day: 22, text: "-10% on Gift Voucher", subtext: "* Discount not combinable with other promotions.", promo_code: "Código: GIFT10OFF" },
                    { day: 23, text: "-20% in Sweatshirts", subtext: "* Discount valid only for New Collection <br> items and cannot be combined with other promotions.", promo_code: "Código: SWEATSHIRTS20" },
                    { day: 24, text: "Free Shipping", subtext: "* Valid only for mainland Portugal.", promo_code: "Código: FREESHIPPING4" },
                    { day: 25, text: "Christmas Mr. Blue <br> -20% Sitewide", subtext: "* Discount valid only for New Collection items and cannot be combined with other promotions.", promo_code: "Código: NATALBLUE" }
                ];
            } else if (window.location.href.includes("mrblue.pt/es/pages/calendario-do-advento-mr-blue-2022")) {
                console.log("ES")
                    /* == DATA SPANISH == */
                days_data = [
                    { day: 1, text: "-20% en toda la web", subtext: "* Descuento válido solo para artículos de Nueva Colección y no acumulable con otras promociones.", promo_code: "Código: SUPER20" },
                    { day: 2, text: "-30% en Accesorios", subtext: "* Descuento válido solo para artículos de Nueva Colección y no acumulable con otras promociones.", promo_code: "Código: ACESSORIOS30" },
                    { day: 3, text: "-15% en Zapatos Formales", subtext: "* Descuento no acumulable con otras promociones.", promo_code: "Código: SAPATOS15" },
                    { day: 4, text: "Envío gratis", subtext: "* Válido solo para Portugal continental.", promo_code: "Código: FREESHIPPING1" },
                    { day: 5, text: "3X2 en Boxers", subtext: "* Descuento directo en el carrito. Válido solo para artículos de Nueva Colección y no acumulable con otras promociones.", promo_code: "" },
                    { day: 6, text: "-25% en pijamas", subtext: "* Descuento válido solo para artículos de Nueva Colección y no acumulable con otras promociones.", promo_code: "Código: PIJAMAS25" },
                    { day: 7, text: "10% adicional al comprar 3 o más artículos", subtext: "* Descuento válido solo para artículos de Nueva Colección y no acumulable con otras promociones.", promo_code: "Código: MAIS10" },
                    { day: 8, text: "20% + 5% EXTRA en Abrigos, <br> Abrigos y Americanas", subtext: "* Descuento válido solo para artículos de Nueva Colección<br> y no acumulable con otras promociones.", promo_code: "Código: EXTRA5" },
                    { day: 9, text: "Envío gratis", subtext: "* Válido solo para Portugal continental.", promo_code: "Código: FREESHIPPING2" },
                    { day: 10, text: "50% + 10% Adicional en Artículos Seleccionados", subtext: "* Descuento no acumulable con otras promociones.", promo_code: "Código: 50MAIS10" },
                    { day: 11, text: "Bufandas <br> -40% en la 2ª prenda", subtext: "* Descuento directo en el carrito. <br>Válido solo para artículos de Nueva Colección <br>y con un precio de 35,99 €. Descuento no acumulable con otras promociones.", promo_code: "" },
                    { day: 12, text: "-15% en Jerséis", subtext: "* Descuento válido solo para artículos de Nueva Colección y no acumulable con otras promociones.", promo_code: "Código: PULLOVERS15" },
                    { day: 13, text: "Reciba un exclusivo Mr. <br>Blue con tu pedido.", subtext: "*Válido para todos los pedidos en línea antes del <br> 13 de diciembre de 2022.", promo_code: "" },
                    { day: 14, text: "-25% en Camisas", subtext: "* Descuento válido solo para artículos de Nueva Colección y no acumulable con otras promociones.", promo_code: "Código: CAMISAS25" },
                    { day: 15, text: "Pañuelos <br> 2 por 29,99€", subtext: "* Descuento directo en el carrito. Válido solo para artículos de Nueva Colección<br> y con un precio de 19,99 €. Descuento no acumulable con otras promociones.", promo_code: "" },
                    { day: 16, text: "5€ en compras superiores a 65€ <br> 10€ en compras superiores a 75€ <br> 25€ en compras superiores a 95€ ", subtext: "* Descuento directo en el carrito. Válido solo para artículos de Nueva Colección<br> y no acumulable con otras promociones.", promo_code: "" },
                    { day: 17, text: "Envío gratis", subtext: "* Válido solo para Portugal continental.", promo_code: "Código: FREESHIPPING3" },
                    { day: 18, text: "2ª camiseta 9,99 €", subtext: "* Descuento directo en el carrito. Válido solo para artículos de Nueva Colección y no acumulable con otras promociones.", promo_code: "" },
                    { day: 19, text: "-25% en pantalones", subtext: "* Descuento válido solo para artículos de Nueva Colección y no acumulable con otras promociones.", promo_code: "Código: CALCAS25" },
                    { day: 20, text: "5 Calcetines por 19,99€", subtext: "* Descuento directo en el carrito. Solo válido para artículos de 12,99 € y no acumulable con otras promociones.", promo_code: "" },
                    { day: 21, text: "-20% en Polos y Rugby", subtext: "* Descuento válido solo para artículos de Nueva Colección y no acumulable con otras promociones.", promo_code: "Código: POLOSERUGBIES20" },
                    { day: 22, text: "-10% en Vale Regalo", subtext: "* Descuento no acumulable con otras promociones.", promo_code: "Código: GIFT10OFF" },
                    { day: 23, text: "-20% en Sudaderas", subtext: "* Descuento válido solo para artículos de Nueva Colección <br> y no acumulable con otras promociones.", promo_code: "Código: SWEATSHIRTS20" },
                    { day: 24, text: "Envío gratis", subtext: "* Válido solo para Portugal continental.", promo_code: "Código: FREESHIPPING4" },
                    { day: 25, text: "Navidad Sr. Blue <br> -20% en todo el sitio", subtext: "* Descuento válido solo para artículos de Nueva Colección y no acumulable con otras promociones.", promo_code: "Código: NATALBLUE" }
                ];
            } else {
                console.log("PT")
                    /* == DATA PORTUGUESE == */
                days_data = [
                    { day: 1, text: "-20% em todo o site", subtext: "* Desconto válido apenas para artigos de Nova Coleção e não acumulável com outras promoções.", promo_code: "Código: SUPER20" },
                    { day: 2, text: "-30% em Acessórios", subtext: "* Desconto válido apenas para artigos de Nova Coleção e não acumulável com outras promoções.", promo_code: "Código: ACESSORIOS30" },
                    { day: 3, text: "-15% em Sapatos Formais", subtext: "* Desconto não acumulável com outras promoções.", promo_code: "Código: SAPATOS15" },
                    { day: 4, text: "Free Shipping", subtext: "*Válido apenas para Portugal Continental.", promo_code: "Código: FREESHIPPING1" },
                    { day: 5, text: "3X2 em Boxers", subtext: "*Desconto direto no carrinho. Válido apenas para artigos de Nova Coleção e não acumulável com outras promoções.", promo_code: "" },
                    { day: 6, text: "25% em Pijamas", subtext: "* Desconto válido apenas para artigos de Nova Coleção e não acumulável com outras promoções.", promo_code: "Código: PIJAMAS25" },
                    { day: 7, text: "10% Adicional na compra de 3 ou mais artigos", subtext: "*Desconto válido apenas para artigos de Nova Coleção e não acumulável com outras promoções.", promo_code: "Código: MAIS10" },
                    { day: 8, text: "20% + 5% EXTRA em Casacos, <br> Sobretudos e Blazers", subtext: "* Desconto válido apenas para artigos de Nova Coleção <br>e não acumulável com outras promoções.", promo_code: "Código: EXTRA5" },
                    { day: 9, text: "Free Shipping", subtext: "*Válido apenas para Portugal Continental.", promo_code: "Código: FREESHIPPING2" },
                    { day: 10, text: "50% + 10% Adicional em Artigos Selecionados", subtext: "* Desconto não acumulável com outras promoções.", promo_code: "Código: 50MAIS10" },
                    { day: 11, text: "Cachecóis <br> -40% no 2º artigo", subtext: "*Desconto direto no carrinho. <br>Válido apenas para artigos de Nova Coleção e com preço de 35.99€. <br>Desconto não acumulável com outras promoções.", promo_code: "" },
                    { day: 12, text: "-15% em Pullovers", subtext: "* Desconto válido apenas para artigos de Nova Coleção e não acumulável com outras promoções.", promo_code: "Código: PULLOVERS15" },
                    { day: 13, text: "Receba um brinde <br>exclusivo  Mr. Blue <br>com a  sua encomenda.", subtext: "*Válido para todas as encomendas online <br>do dia 13 de Dezembro 2022.", promo_code: "" },
                    { day: 14, text: "-25% em Camisas", subtext: "* Desconto válido apenas para artigos de Nova Coleção e não acumulável com outras promoções.", promo_code: "Código: CAMISAS25" },
                    { day: 15, text: "Cachecóis <br> 2 por 29.99€", subtext: "*Desconto direto no carrinho. Válido apenas para artigos de Nova Coleção<br> e com preço de 19.99€. Desconto não acumulável com outras promoções.", promo_code: "" },
                    { day: 16, text: "5€ em compras superiores a 65€ <br> 10€ em compras superiores a 75€ <br> 25€ em compras superiores a 95€ ", subtext: "*Desconto direto no carrinho. Válido apenas para atigos de Nova Coleção<br> e não acumulável com outras promoções.", promo_code: "" },
                    { day: 17, text: "Free Shipping", subtext: "*Válido apenas para Portugal Continental.", promo_code: "Código: FREESHIPPING3" },
                    { day: 18, text: "2ª T-shirt a 9.99€", subtext: "*Desconto direto no carrinho. Válido apenas para atigos de Nova Coleção e não acumulável com outras promoções.", promo_code: "" },
                    { day: 19, text: "-25% em Calças", subtext: "* Desconto válido apenas para artigos de Nova Coleção e não acumulável com outras promoções.", promo_code: "Código: CALCAS25" },
                    { day: 20, text: "5 Meias por 19.99€", subtext: "*Desconto direto no carrinho. Válido apenas para atigos de 12.99€ e não acumulável com outras promoções.", promo_code: "" },
                    { day: 21, text: "-20% em Polos & Rugbies", subtext: "* Desconto válido apenas para artigos de Nova Coleção e não acumulável com outras promoções.", promo_code: "Código: POLOSERUGBIES20" },
                    { day: 22, text: "-10% em Gift Voucher", subtext: "* Desconto não acumulável com outras promoções.", promo_code: "Código: GIFT10OFF" },
                    { day: 23, text: "-20% em Sweatshirts", subtext: "* Desconto válido apenas para artigos de Nova Coleção<br> e não acumulável com outras promoções.", promo_code: "Código: SWEATSHIRTS20" },
                    { day: 24, text: "Free Shipping", subtext: "*Válido apenas para Portugal Continental.", promo_code: "Código: FREESHIPPING4" },
                    { day: 25, text: "Natal Mr. Blue <br> -20% em todo o site", subtext: "* Desconto válido apenas para artigos de Nova Coleção e não acumulável com outras promoções.", promo_code: "Código: NATALBLUE" }
                ];
            }

            for (var i = 0; i < days_data.length; i++) {
                if (days_data[i]["day"] == $(this).attr("data-id")) {

                    var day = days_data[i]["day"];
                    var text = days_data[i]["text"];
                    var subtext = days_data[i]["subtext"];
                    var promo_code = days_data[i]["promo_code"];

                    var html = `<button type="button" class="btn-close-gift" aria-label="Close">X</button>
              <div class="advento" style=background-image:url(` + bg_image + `); background-size: contain; position:relative;>
                <div class="advento_bg">
                  <p class="title">` + day + `</p>
                  <span class="text B-exlight-italic">` + text + `</span>
                  <span class="subtext">` + subtext + `</span>
                  <span class="promo_code d-none" onClick=copyClipboard()>` + promo_code + `</span>
                  <span class="promo_code_copied d-none">` + promo_code + ` copiado. </span>
                  <button type="button" class="button-buy d-none"><a href="/pages/calendario-do-advento-mr-blue-2022">BUY</a></button>
                </div>
              </div>`;

                    $(this).append(html)

                    if ($(this).find(".promo_code")[0].innerText != "") {
                        $(this).find(".promo_code").removeClass("d-none");
                    }

                    $("body").addClass("overflow-hidden")

                    $(".btn-close-gift").click(function(e) {
                        setTimeout(function() {
                            $("body").click();
                            $("body").addClass("transform_unset");
                            $("body").removeClass("overflow-hidden")
                        }, 200)
                    });

                    /*$("body").click(function(e){
                      setTimeout(function(){
                        $("body").removeClass("overflow-hidden")
                      },200)
                    })*/

                }
            }

        });

        $(".grid__item.not_yet").click(function(e) {
            $(this).css("animation", "shake 0.5s")
        });

    }

});

function copyClipboard() {
    navigator.clipboard.writeText($(".promo_code").text().replace("Código: ", ""));
    setTimeout(function() {
        $(".promo_code_copied").removeClass("d-none");
        setTimeout(function() {
            $(".promo_code_copied").addClass("d-none");
        }, 2000);
    }, 500)

}